//
//  DetailAnnotation.m
//  weather_app(URLsession_training)
//
//  Created by Roman Osadchuk on 29.01.16.
//  Copyright © 2016 Roman Osadchuk. All rights reserved.
//

#import "DetailAnnotation.h"

@implementation DetailAnnotation

-(void)setCoordinate:(CLLocationCoordinate2D)newCoordinate
{
    _coordinate = newCoordinate;
}

@end
