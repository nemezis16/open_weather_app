//
//  InfoWeatherViewController.h
//  weather_app(URLsession_training)
//
//  Created by Roman Osadchuk on 27.01.16.
//  Copyright © 2016 Roman Osadchuk. All rights reserved.
//

@interface InfoWeatherViewController : UIViewController  <MKMapViewDelegate,CLLocationManagerDelegate>

@end
